
Ludo Game Instructions

Objective:
The objective of the game is to move all your pieces from the starting position to the home position by rolling the dice and moving the pieces accordingly.

Setup:
1. Start the game by running the application.
2. The game board will be displayed with four colored pieces: red, green, blue, and yellow.

Controls:
- Press 'R' to roll the dice and move the red piece.
- Press 'G' to roll the dice and move the green piece.
- Press 'B' to roll the dice and move the blue piece.
- Press 'Y' to roll the dice and move the yellow piece.

Gameplay:
1. Press the corresponding key (R, G, B, Y) to roll the dice for the respective colored piece.
2. The dice result will be displayed on the screen.
3. A piece will move from home box to the starting position only when a '6' scored.
4. The piece will move according to the dice result.
5. If multiple pieces are out of home box, a prompt will appear to select a piece to move.
6. The game continues until all pieces reach their home positions.

Winning:
The player who successfully moves all their pieces to the home position first wins the game.

Exiting the Game:
- Press the close button on the game window or use the keyboard shortcut to quit the game.

Help:
- Press 'H' for help at any time.

Enjoy playing Ludo!
